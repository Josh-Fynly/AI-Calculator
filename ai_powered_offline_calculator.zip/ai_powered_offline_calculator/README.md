# AI-Powered Offline Calculator

A simple offline natural language calculator built with Python and Kivy.

## 🔧 Features
- Natural language input: e.g., "What is 15% of 200?"
- Cross-platform
- Works offline

## 📱 Build APK on Android

### Manual Build with Buildozer
```bash
sudo apt install python3-pip build-essential git openjdk-17-jdk -y
pip install buildozer
buildozer android debug
```

### GitHub Actions Auto-Build

This repo includes a GitHub Action that builds your APK automatically on push.
