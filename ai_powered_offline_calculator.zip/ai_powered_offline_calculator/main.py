from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
import re

def calculate(expression):
    expression = expression.lower()
    if "percent of" in expression:
        match = re.search(r"(\d+)\s*percent of\s*(\d+)", expression)
        if match:
            percent = float(match.group(1))
            base = float(match.group(2))
            return str((percent / 100) * base)
    if "add" in expression or "plus" in expression:
        nums = [float(x) for x in re.findall(r'\d+', expression)]
        return str(sum(nums))
    if "subtract" in expression or "minus" in expression:
        nums = [float(x) for x in re.findall(r'\d+', expression)]
        return str(nums[0] - nums[1])
    if "multiply" in expression or "times" in expression:
        nums = [float(x) for x in re.findall(r'\d+', expression)]
        result = 1
        for n in nums:
            result *= n
        return str(result)
    if "divide" in expression or "by" in expression:
        nums = [float(x) for x in re.findall(r'\d+', expression)]
        return str(nums[0] / nums[1])
    return "Sorry, I don't understand that."

class SimplexCalculator(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', padding=10, spacing=10, **kwargs)
        self.input = TextInput(hint_text="Enter a math question", multiline=False, size_hint_y=0.2)
        self.add_widget(self.input)
        self.button = Button(text="Calculate", size_hint_y=0.2)
        self.button.bind(on_press=self.calculate_result)
        self.add_widget(self.button)
        self.output = Label(text="", size_hint_y=0.6)
        self.add_widget(self.output)

    def calculate_result(self, instance):
        user_input = self.input.text
        self.output.text = "Answer: " + calculate(user_input)

class SimplexApp(App):
    def build(self):
        return SimplexCalculator()

if __name__ == '__main__':
    SimplexApp().run()
